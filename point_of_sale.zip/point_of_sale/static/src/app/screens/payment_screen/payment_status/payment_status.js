/** @odoo-module */

import { Component } from "@odoo/owl";
import { usePos } from "@point_of_sale/app/store/pos_hook";


export class PaymentScreenStatus extends Component {
    static template = "point_of_sale.PaymentScreenStatus";

    setup() {
        this.pos = usePos();
        this.payment_methods_from_config = this.pos.payment_methods.filter((method) =>
            this.pos.config.payment_method_ids.includes(method.id)
        );
    }

    get changeText() {
        return this.env.utils.formatCurrency(this.props.order.get_change());
    }
    get totalDueText() {
        const total_due =  this.props.order.get_total_with_tax() + this.props.order.get_rounding_applied()
        if (this.is_credit_card == true){
            return this.env.utils.formatCurrency(
               total_due + (total_due * this.pos.config.pos_additional_charge /100)
            );            
        }
        else {
            return this.env.utils.formatCurrency(total_due);
        }

    }
 
    get remainingText() {
        return this.env.utils.formatCurrency(
            this.props.order.get_due() > 0 ? this.props.order.get_due() : 0
        );
    }
    get is_credit_card(){
        let card = false
        for (const payment of this.props.order.get_paymentlines()){
            if (payment.name == 'Credit Card'){
              card = true
            }
        }
        return card
    }

    get AdditionalChargeText() {
        return this.env.utils.formatCurrency(
            (this.props.order.get_total_with_tax() + this.props.order.get_rounding_applied()) * this.pos.config.pos_additional_charge /100
        );
    }
    
}
